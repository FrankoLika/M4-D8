document.addEventListener("DOMContentLoaded", async () => {
    //aggiungo la navbar presente in "Common.html" in "Index.html" al caricamento della pagina
    document.getElementById("navbar").innerHTML = '<object type="text/html" style="height: 100%; width: 100%" data="Common.html"></object>';


    //faccio una fetch con l'endpoint dichiarato in "Common.js" 
    try {
        document.getElementById("loader").classList.remove("d-none");
        const response = await fetch(endpoint, {
            headers: {
                Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NDMyYzRmNGVmNmI2MDAwMTRmYjM0YWMiLCJpYXQiOjE2ODEwNDg4MjMsImV4cCI6MTY4MjI1ODQyM30.tb_b0yi7N3c-l2KvuQTyO3wk2hKL47hWWseV6TKzec4",
            },
        });
        if (response.ok) { //se la risposta è andata a buon fine faccio un json del risultato
            const data = await response.json();
            document.getElementById("loader").classList.add("d-none");
            showProducts(data);//passiamo i prodotti nella funzione showProducts
        } else { //se la risposta è andata male mostro in console un messaggio di errore
            console.log('Get products failed');
        }
    } catch (error) {
        console.log("Error here : " + error);
    }
})

function showProducts(arrayProducts) {

    //forEach per mostrare i prodotti
    arrayProducts.forEach((item, i) => {
        let divCol = document.createElement("div");
        divCol.className = "col";
        divCol.id = item._id;

        let divCard = document.createElement("div");
        divCard.className = "card";

        let divBody = document.createElement("div");
        divBody.className = "card-body";

        let img = document.createElement("img");
        img.src = item.imageUrl;
        img.style.width = "100%"
        img.style.height = "150px"
        img.style.objectFit = "none"

        let title = document.createElement("h5");
        title.className = "card-title";
        title.innerText = item.name;

        let description = document.createElement("p");
        description.className = "card-text";
        description.innerText = item.description;

        let brand = document.createElement("p");
        brand.className = "card-text";
        brand.innerText = item.brand;

        let price = document.createElement("p");
        price.className = "card-text";
        price.innerText = item.price + "€";

        let mostraProdotto = document.createElement("a");
        mostraProdotto.className = "btn btn-primary";
        mostraProdotto.innerText = "Mostra Prodotto"
        mostraProdotto.href = "Product.html?id=" + item._id
        mostraProdotto.target = "_blank";//per aprire una nuova finistra

        divBody.append(img, title, description, brand, price, mostraProdotto);
        divCard.appendChild(divBody);
        divCol.appendChild(divCard);

        document.getElementById("containerProducts").appendChild(divCol);
    })
}

//funzione per refreshare la pagina
function refresh() {
    window.location.reload();
}