const endpoint = "https://striveschool-api.herokuapp.com/api/product/";


