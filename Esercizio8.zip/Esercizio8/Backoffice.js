document.addEventListener("DOMContentLoaded", () => {
     //aggiungo la navbar presente in "Common.html" in "Index.html" al caricamento della pagina
     document.getElementById("navbar").innerHTML = '<object type="text/html" style="height: 100%; width: 100%" data="Common.html"></object>';
})

function createObject() {
     let name = document.getElementById("name").value;
     let description = document.getElementById("description").value;
     let brand = document.getElementById("brand").value;
     let imageUrl = document.getElementById("imageUrl").value;
     let price = document.getElementById("price").value;

     //controllo sui vari campi
     if (name === "") {
          alert("il campo 'nome' non può essere vuoto");
     } else if (description === "") {
          alert("il campo 'description' non può essere vuoto");
     } else if (brand === "") {
          alert("il campo 'brand' non può essere vuoto");
     } else if (imageUrl === "") {
          alert("il campo 'imageUrl' non può essere vuoto");
     } else if (price === "") {
          alert("Il campo 'price' non può essere vuoto ");
     } else if (price.includes("$") || price.includes("€") || price.includes("£")) {
          alert("Il campo price non accetta simboli ($, €, £)");
     } else if (isNaN(price)) {
          alert("Il campo price accetta solo numeri");
     } else { //altrimenti creo oggetto e avvio funzione
          const product = {
               name: name,
               description: description,
               brand: brand,
               imageUrl: imageUrl,
               price: price,
          }
          addProducts(product);
          window.location.reload();
          alert("added")
     }
}

//funzione fetch con il metodo post per aggiungere il prodotto
async function addProducts(product) {
     try {
          const response = await fetch(endpoint, {
               headers: {
                    Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NDMyYzRmNGVmNmI2MDAwMTRmYjM0YWMiLCJpYXQiOjE2ODEwNDg4MjMsImV4cCI6MTY4MjI1ODQyM30.tb_b0yi7N3c-l2KvuQTyO3wk2hKL47hWWseV6TKzec4",
                    "Content-type": "application/json",
               },
               method: "POST",
               body: JSON.stringify(product),
          });
          await response.json().then((data) => {
          });
     } catch (error) {
          console.log("Error here : " + error);
     }
}

//funzione per fare la fetch e far partire la funzione "showProductsForEdit"
async function editProduct() {
     document.getElementById("col2").classList.add("d-none");
     document.getElementById("tableAdd").classList.add("d-none");
     document.getElementById("tableRemove").classList.add("d-none");
     document.getElementById("tableEdit").classList.add("d-none");

     try {
          const response = await fetch(endpoint, {
               headers: {
                    Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NDMyYzRmNGVmNmI2MDAwMTRmYjM0YWMiLCJpYXQiOjE2ODEwNDg4MjMsImV4cCI6MTY4MjI1ODQyM30.tb_b0yi7N3c-l2KvuQTyO3wk2hKL47hWWseV6TKzec4",
               },
          });
          if (response.ok) { //se la risposta è andata a buon fine faccio un json del risultato
               const data = await response.json();
               showProductsForEdit(data);//passiamo i prodotti nella funzione showProductsforEdit
          } else { //se la risposta è andata male mostro in console un messaggio di errore
               console.log('Get products failed');
          }
     } catch (error) {
          console.log("Error here : " + error);
     }
}

//questa funzione riceve i dati della fetch e costruisce una tabella con tutti gli oggetti presenti nella fetch
//accanto ad ogni nome c'è un bottone con su "Edit" che schiacciato ti fa modificare i valori
function showProductsForEdit(products) {

     let container = document.getElementById("colTable");

     let table = document.createElement("table");
     table.style.width = "800px"

     let tr = document.createElement("tr");
     let td = document.createElement("td");
     let td2 = document.createElement("td");
     let td3 = document.createElement("td");

     td.innerText = "Id";
     td2.innerText = "Name";

     td.className = "text-warning fw-bold bg-dark px-2"
     td2.className = "text-warning fw-bold bg-dark px-2"
     td3.className = "text-warning fw-bold bg-dark"

     tr.append(td, td2, td3);

     table.appendChild(tr);

     let btnRefresh = document.createElement("button");
     btnRefresh.style.width = "80px";
     btnRefresh.style.height = "30px";
     btnRefresh.innerText = "Home";
     btnRefresh.className = "border-0 bg-danger rounded-2 text-black mb-3"
     btnRefresh.onclick = () => {
          window.location.reload();
     }


     products.forEach((item, i) => {
          let tr = document.createElement("tr");
          let td = document.createElement("td");
          let td2 = document.createElement("td");
          let td3 = document.createElement("td");
          td.className = "text-white bg-dark px-2"
          td2.className = "text-white bg-dark py-2 px-2"
          td3.className = "text-white bg-dark"

          let btn = document.createElement("button");
          btn.innerText = "Edit"
          btn.className = "border-0 bg-warning rounded-2 text-black"
          btn.onclick = () => {
               edit(item._id, products);
          }

          td.innerText = item._id;
          td2.innerText = item.name;

          td3.appendChild(btn);
          tr.append(td, td2, td3);
          table.appendChild(tr);
     })
     container.append(btnRefresh, table);
}

async function edit(id, products) {
     //const product = await products.find(item => item.id === id); con find non riesco a prendere l'oggetto 
     //specifico dell' array e quindi faccio una nuova fetch con l'id

     let product;
     try {
          const response = await fetch(endpoint + id, {
               headers: {
                    Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NDMyYzRmNGVmNmI2MDAwMTRmYjM0YWMiLCJpYXQiOjE2ODEwNDg4MjMsImV4cCI6MTY4MjI1ODQyM30.tb_b0yi7N3c-l2KvuQTyO3wk2hKL47hWWseV6TKzec4",
               },
          });
          if (response.ok) { //se la risposta è andata a buon fine faccio un json del risultato
               const data = await response.json();
               product = data;

          } else { //se la risposta è andata male mostro in console un messaggio di errore
               console.log('Get products failed');
          }
     } catch (error) {
          console.log("Error here : " + error);
     }

     let btnRefresh = document.createElement("button");
     btnRefresh.style.width = "80px";
     btnRefresh.style.height = "30px";
     btnRefresh.innerText = "Home";
     btnRefresh.className = "border-0 bg-danger rounded-2 text-black mx-3"
     btnRefresh.onclick = () => {
          window.location.reload();
     }



     document.getElementById("colTable").className = "d-none";

     let containerTable = document.getElementById("containerTable");


     let table = document.createElement("table");
     table.className = "table tableStyle";


     let tr = document.createElement("tr");
     let tdcSpan = document.createElement("td");
     tdcSpan.colSpan = "2";
     let divForTdc = document.createElement("div");
     divForTdc.className = "text-warning text-center fw-bold bg-dark";
     divForTdc.innerText = "Edit Product";
     tdcSpan.appendChild(divForTdc);
     tr.appendChild(tdcSpan);


     let trName = document.createElement("tr");
     let tdName1 = document.createElement("td");
     tdName1.className = "text-black fw-bold";
     tdName1.innerText = "Name :";
     tdName1.style.paddingTop = "10px";
     let tdName2 = document.createElement("td");
     let inputName = document.createElement("input");
     inputName.style.marginTop = "10px";
     inputName.id = "newName";
     inputName.value = product.name;
     tdName2.appendChild(inputName);
     trName.append(tdName1, tdName2);

     let trDescription = document.createElement("tr");
     let tdDescription1 = document.createElement("td");
     tdDescription1.className = "text-black fw-bold";
     tdDescription1.innerText = "Description :";
     tdDescription1.style.paddingTop = "10px";
     let tdDescription2 = document.createElement("td");
     let inputDescription = document.createElement("input");
     inputDescription.id = "newDescription";
     inputDescription.style.marginTop = "10px";
     inputDescription.value = product.description;
     tdDescription2.appendChild(inputDescription);
     trDescription.append(tdDescription1, tdDescription2);

     let trBrand = document.createElement("tr");
     let tdBrand1 = document.createElement("td");
     tdBrand1.className = "text-black fw-bold";
     tdBrand1.innerText = "Brand :"
     tdBrand1.style.paddingTop = "10px";
     let tdBrand2 = document.createElement("td");
     let inputBrand = document.createElement("input");
     inputBrand.id = "newBrand";
     inputBrand.style.marginTop = "10px";
     inputBrand.value = product.brand;
     tdBrand2.appendChild(inputBrand);
     trBrand.append(tdBrand1, tdBrand2);

     let trImageUrl = document.createElement("tr");
     let tdImageUrl1 = document.createElement("td");
     tdImageUrl1.className = "text-black fw-bold";
     tdImageUrl1.innerText = "ImageUrl :";
     tdImageUrl1.style.paddingTop = "10px";
     let tdImageUrl2 = document.createElement("td");
     let inputImageUrl = document.createElement("input");
     inputImageUrl.id = "newImageUrl";
     inputImageUrl.style.marginTop = "10px";
     inputImageUrl.value = product.imageUrl;
     tdImageUrl2.appendChild(inputImageUrl);
     trImageUrl.append(tdImageUrl1, tdImageUrl2);

     let trPrice = document.createElement("tr");
     let tdPrice1 = document.createElement("td");
     tdPrice1.className = "text-black fw-bold";
     tdPrice1.innerText = "Price :";
     tdPrice1.style.paddingTop = "10px";
     let tdPrice2 = document.createElement("td");
     let inputPrice = document.createElement("input");
     inputPrice.id = "newPrice";
     inputPrice.style.marginTop = "10px";
     inputPrice.value = product.price;
     tdPrice2.appendChild(inputPrice);
     trPrice.append(tdPrice1, tdPrice2);

     let trButton = document.createElement("tr");
     let tdcSpanButton = document.createElement("td");
     tdcSpanButton.colSpan = "2";
     let button = document.createElement("button");
     button.className = "border-0 bg-warning rounded-2 text-black submit";
     button.style.marginTop = "10px";
     button.innerText = "Save";
     tdcSpanButton.appendChild(button);
     trButton.appendChild(tdcSpanButton);

     button.onclick = async () => {
          let newname = document.getElementById("newName").value;
          let newdescription = document.getElementById("newDescription").value;
          let newbrand = document.getElementById("newBrand").value;
          let newimageUrl = document.getElementById("newImageUrl").value;
          let newprice = document.getElementById("newPrice").value;

          const newProduct = {
               name: newname,
               description: newdescription,
               brand: newbrand,
               imageUrl: newimageUrl,
               price: newprice,
          }

          //metodo PUT prendendo l'oggetto "newProduct"
          try {
               const responsePut = await fetch(endpoint + id, {
                    headers: {
                         Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NDMyYzRmNGVmNmI2MDAwMTRmYjM0YWMiLCJpYXQiOjE2ODEwNDg4MjMsImV4cCI6MTY4MjI1ODQyM30.tb_b0yi7N3c-l2KvuQTyO3wk2hKL47hWWseV6TKzec4",
                         "Content-type": "application/json",
                    },
                    method: "PUT",
                    body: JSON.stringify(newProduct),

               });
               if (responsePut.ok) { //se la risposta è andata a buon fine faccio un json del risultato
                    const dataPut = await responsePut.json();
               } else { //se la risposta è andata male mostro in console un messaggio di errore
                    console.log('Get products failed');
               }
               window.location.reload();
               alert("Saved");
          } catch (error) {
               console.log("Error here : " + error);
          }
     }


     table.append(tr, trName, trDescription, trBrand, trImageUrl, trPrice, trButton);
     containerTable.append(btnRefresh, table);


}



async function removeProduct() {
     document.getElementById("tableAdd").classList.add("d-none");
     document.getElementById("tableRemove").classList.add("d-none");
     document.getElementById("tableEdit").classList.add("d-none");
     document.getElementById("col2").classList.add("d-none");

     try {
          const response = await fetch(endpoint, {
               headers: {
                    Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NDMyYzRmNGVmNmI2MDAwMTRmYjM0YWMiLCJpYXQiOjE2ODEwNDg4MjMsImV4cCI6MTY4MjI1ODQyM30.tb_b0yi7N3c-l2KvuQTyO3wk2hKL47hWWseV6TKzec4",
               },
          });
          if (response.ok) { //se la risposta è andata a buon fine faccio un json del risultato
               const data = await response.json();
               showProductsForDelete(data);//passiamo i prodotti nella funzione showProductsforEdit
          } else { //se la risposta è andata male mostro in console un messaggio di errore
               console.log('Get products failed');
          }
     } catch (error) {
          console.log("Error here : " + error);
     }
}

function showProductsForDelete(products) {
     let container = document.getElementById("colTable");

     let table = document.createElement("table");
     table.style.width = "800px"

     let tr = document.createElement("tr");
     let td = document.createElement("td");
     let td2 = document.createElement("td");
     let td3 = document.createElement("td");

     td.innerText = "Id";
     td2.innerText = "Name";

     td.className = "text-warning fw-bold bg-dark px-2"
     td2.className = "text-warning fw-bold bg-dark px-2"
     td3.className = "text-warning fw-bold bg-dark"

     tr.append(td, td2, td3);

     table.appendChild(tr);


     products.forEach((item, i) => {
          let tr = document.createElement("tr");
          let td = document.createElement("td");
          let td2 = document.createElement("td");
          let td3 = document.createElement("td");
          td.className = "text-white bg-dark px-2"
          td2.className = "text-white bg-dark py-2 px-2"
          td3.className = "text-white bg-dark"

          let btn = document.createElement("button");
          btn.innerText = "Delete"
          btn.className = "border-0 bg-warning rounded-2 text-black"
          btn.onclick = () => {
               deleteP(item._id);
          }

          td.innerText = item._id;
          td2.innerText = item.name;

          td3.appendChild(btn);
          tr.append(td, td2, td3);
          table.appendChild(tr);
     })
     let btnRefresh = document.createElement("button");
     btnRefresh.style.width = "80px";
     btnRefresh.style.height = "30px";
     btnRefresh.innerText = "Home";
     btnRefresh.className = "border-0 bg-danger rounded-2 text-black mb-3"
     btnRefresh.onclick = () => {
          window.location.reload();
     }
     container.append(btnRefresh, table);

}

async function deleteP(id) {
     //Metodo delete che elimina un determinato prodotto preso dall'id passato dal bottone
     try {
          const responsePut = await fetch(endpoint + id, {
               headers: {
                    Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NDMyYzRmNGVmNmI2MDAwMTRmYjM0YWMiLCJpYXQiOjE2ODEwNDg4MjMsImV4cCI6MTY4MjI1ODQyM30.tb_b0yi7N3c-l2KvuQTyO3wk2hKL47hWWseV6TKzec4",
                    "Content-type": "application/json",
               },
               method: "delete",
          });
          if (responsePut.ok) { //se la risposta è andata a buon fine faccio un json del risultato
               const dataPut = await responsePut.json();
          } else { //se la risposta è andata male mostro in console un messaggio di errore
               console.log('Get products failed');
          }
          alert("deleted");
          window.location.reload();
     } catch (error) {
          console.log("Error here : " + error);
     }
}