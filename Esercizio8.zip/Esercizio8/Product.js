document.addEventListener("DOMContentLoaded", async () => {
    //aggiungo la navbar presente in "Common.html" in "Index.html" al caricamento della pagina
    document.getElementById("navbar").innerHTML = '<object type="text/html" style="height: 100%; width: 100%" data="Common.html"></object>';


    let variabiliPassate = new URLSearchParams(window.location.search);
    let id = variabiliPassate.get("id");

    let product;

    try {
        const response = await fetch(endpoint + id, {
            headers: {
                Authorization: "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2NDMyYzRmNGVmNmI2MDAwMTRmYjM0YWMiLCJpYXQiOjE2ODEwNDg4MjMsImV4cCI6MTY4MjI1ODQyM30.tb_b0yi7N3c-l2KvuQTyO3wk2hKL47hWWseV6TKzec4",
            },
        });
        if (response.ok) { //se la risposta è andata a buon fine faccio un json del risultato
            const data = await response.json();
            product = data;
        } else { //se la risposta è andata male mostro in console un messaggio di errore
            console.log('Get products failed');
        }
    } catch (error) {
        console.log("Error here : " + error);
    }


    let divCont = document.createElement("div");
    divCont.className = "card";
    divCont.style.width = "14rem";

    let img = document.createElement("img");
    img.className = "card-img-top";
    img.src = product.imageUrl;


    let divBody = document.createElement("div");
    divBody.className = "card-body";

    let h5 = document.createElement("h5");
    h5.className = "card-title";
    h5.innerText = product.name;

    let pDescription = document.createElement("p");
    pDescription.className = "card-text";
    pDescription.innerText = product.description;

    let pBrand = document.createElement("p");
    pBrand.className = "card-text";
    pBrand.innerText = product.brand;

    let pPrice = document.createElement("p");
    pPrice.className = "card-text";
    pPrice.innerText = product.price + "€";


    divBody.append(h5, pDescription, pBrand, pPrice);
    divCont.append(img, divBody);

    document.getElementById("containerProduct").appendChild(divCont);

})